/*
SQLyog Community v13.2.0 (64 bit)
MySQL - 5.7.33 : Database - db_hrapp
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `hr_departement` */

DROP TABLE IF EXISTS `hr_departement`;

CREATE TABLE `hr_departement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `cby` int(11) DEFAULT NULL,
  `uby` int(11) DEFAULT NULL,
  `con` timestamp NULL DEFAULT NULL,
  `uon` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `hr_departement` */

insert  into `hr_departement`(`id`,`name`,`cby`,`uby`,`con`,`uon`) values 
(1,'Human Resources',NULL,NULL,NULL,NULL),
(2,'Keuangan',NULL,NULL,NULL,NULL),
(3,'Manajemen',NULL,NULL,NULL,NULL),
(4,'Produksi',NULL,NULL,NULL,NULL);

/*Table structure for table `hr_employee_position` */

DROP TABLE IF EXISTS `hr_employee_position`;

CREATE TABLE `hr_employee_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employeeId` int(11) DEFAULT NULL,
  `departementId` int(11) DEFAULT NULL,
  `positionId` int(11) DEFAULT NULL,
  `activeDate` date DEFAULT NULL,
  `cby` int(11) DEFAULT NULL,
  `uby` int(11) DEFAULT NULL,
  `con` timestamp NULL DEFAULT NULL,
  `uon` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `hr_employee_position` */

insert  into `hr_employee_position`(`id`,`employeeId`,`departementId`,`positionId`,`activeDate`,`cby`,`uby`,`con`,`uon`) values 
(1,12,NULL,1,'2001-01-19',NULL,NULL,NULL,NULL),
(2,13,NULL,2,'2005-11-20',NULL,NULL,NULL,NULL),
(3,14,NULL,3,'2019-01-08',NULL,NULL,NULL,NULL),
(4,15,NULL,4,'2022-02-05',NULL,NULL,NULL,NULL);

/*Table structure for table `hr_position` */

DROP TABLE IF EXISTS `hr_position`;

CREATE TABLE `hr_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `depertementId` int(11) DEFAULT NULL,
  `cby` int(11) DEFAULT NULL,
  `uby` int(11) DEFAULT NULL,
  `con` timestamp NULL DEFAULT NULL,
  `uon` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `hr_position` */

insert  into `hr_position`(`id`,`name`,`depertementId`,`cby`,`uby`,`con`,`uon`) values 
(1,'Supervisor HR',1,NULL,NULL,NULL,NULL),
(2,'Asisten Manager Keuangan',2,NULL,NULL,NULL,NULL),
(3,'Sekretaris',3,NULL,NULL,NULL,NULL),
(4,'Manager Produksi',4,NULL,NULL,NULL,NULL);

/*Table structure for table `ms_employee` */

DROP TABLE IF EXISTS `ms_employee`;

CREATE TABLE `ms_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(50) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `cby` char(1) DEFAULT NULL,
  `uby` char(1) DEFAULT NULL,
  `con` timestamp NULL DEFAULT NULL,
  `uon` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `ms_employee` */

insert  into `ms_employee`(`id`,`nip`,`name`,`sex`,`startDate`,`endDate`,`cby`,`uby`,`con`,`uon`) values 
(12,'1000','Lukman Hakim','L','1990-05-05','0000-00-00',NULL,NULL,NULL,NULL),
(13,'1001','Saiful Anwar','L','1988-01-10','0000-00-00',NULL,NULL,NULL,NULL),
(14,'1002','Sinta Mei','P','2019-08-01','0000-00-00',NULL,NULL,NULL,NULL),
(15,'1003','Tubagus','L','1986-03-20','0000-00-00',NULL,NULL,NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
